import Loader from "@/components/loader";

export default Loader;
